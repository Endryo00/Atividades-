//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    public static void main(String[] args)
    {
        int[]  numero = {3, 6, 9, 12};

        int soma = numero[0] + numero[numero.length - 1];

        System.out.println("A soma do primeiro e último elemento é: " + soma);
    }

}