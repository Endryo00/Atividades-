//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        int[] numeros = new int[3];

        System.out.println("Por favor, insira três números:");
        for (int i = 0; i < numeros.length; i++)
        {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        scanner.close();

        System.out.println("Valores inseridos:");
        for (int i = 0; i < numeros.length; i++)
        {
            System.out.println("Número " + (i + 1) + ": " + numeros[i]);
        }

        int soma = 0;
        for (int i = 0; i < numeros.length; i++)
        {
            soma += numeros[i];
        }
        double media = (double) soma / numeros.length;

        System.out.println("A média dos valores é: " + media);
    }
}