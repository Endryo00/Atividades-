//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main
{
    public static void main(String[] args)
    {
        int[] numeros = {5, 10};

        System.out.println("Valores originais:");
        System.out.println("Posição 0: " + numeros[0]);
        System.out.println("Posição 1: " + numeros[1]);

        int temp = numeros[0];
        numeros[0] = numeros[1];
        numeros[1] = temp;

        System.out.println("Valores após a troca:");
        System.out.println("Posição 0: " + numeros[0]);
        System.out.println("Posição 1: " + numeros[1]);
    }
}