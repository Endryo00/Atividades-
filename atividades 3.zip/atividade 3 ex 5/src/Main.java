//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        String[] nomes = new String[3];

        System.out.println("Por favor, insira três nomes:");
        for (int i = 0; i < nomes.length; i++)
        {
            System.out.print("Nome " + (i + 1) + ": ");
            nomes[i] = scanner.nextLine();
        }

        scanner.close();

        System.out.println("Nomes inseridos:");
        for (int i = 0; i < nomes.length; i++)
        {
            System.out.println("Nome " + (i + 1) + ": " + nomes[i]);
        }
    }
}