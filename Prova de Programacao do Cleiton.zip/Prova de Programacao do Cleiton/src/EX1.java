import java.util.Scanner;

public class EX1
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe a quantia de alimentos: ");
        int QuantiaAlimentos = scanner.nextInt();
        double[] notas = new double[QuantiaAlimentos];
        int AlimentosBons = 0;
        int AlimentosRuins = 0;
        double somaNotas = 0.0;

        for (int i = 0; i < QuantiaAlimentos; ++i)
        {
            System.out.print("Digite a nota, de 0 a 10, do alimento " + (i + 1) + ": ");
            double nota = scanner.nextDouble();
            if (!(nota < 0.0) && !(nota > 10.0))
            {
                notas[i] = nota;
                somaNotas += nota;
                if (nota >= 6.0)
                {
                    ++AlimentosBons;
                }
                else
                {
                    ++AlimentosRuins;
                }
            }
            else
            {
                System.out.println("Nota inválida! A nota do alimento deve estar entre 0 e 10.");
                --i;
            }
        }

        double media = somaNotas / (double) QuantiaAlimentos;
        System.out.println("Média da nota dos alimentos: " + media);
        System.out.println("Quantidade de Alimentos bons: " + AlimentosBons);
        System.out.println("Quantidade de Alimentos ruins: " + AlimentosRuins);
        scanner.close();
    }
}
