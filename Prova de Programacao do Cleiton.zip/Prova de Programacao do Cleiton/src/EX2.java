import java.util.Scanner;

public class EX2
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Informe a quantia de pessoas que irão votar: ");
        int QV = scanner.nextInt();
        System.out.println("A quantia de votantes é: " + QV);
        int TC=0;
        int PB=0;
        int LF=0;
        int SRF=0;
        int nota=0;

        System.out.println("Os times a são: ");
        System.out.println("1- Taffismo Club");
        System.out.println("2- Patinho Branquinho");
        System.out.println("3- Lucas FC");
        System.out.println("4- Sport Redes FC");

        for(int i=0; i<QV; i++)
        {
            System.out.println("Informe para qual time você vai votar: ");
            nota = scanner.nextInt();
                    if (nota == 1)
                    {
                        TC++;
                    }
                    else if (nota == 2)
                    {
                        PB++;
                    }
                    else if (nota == 3)
                    {
                        LF++;
                    }
                    else if (nota == 4)
                    {
                        SRF++;
                    }
                    else
                    {
                        System.out.println("Numero invalido, cheque o número dos times e vote novamente.");
                        i--;
                    }
        }

        System.out.println("Votação encerrada, os resultados são: ");
        System.out.println("Taffismo Club: " + TC);
        System.out.println("Patinho Branquinho: " + PB);
        System.out.println("Lucas FC: " + LF);
        System.out.println("Sport Redes FC: " + SRF);

        if(TC>PB&&TC>LF&&TC>SRF)
        {
            System.out.println("O time vencedor é Taffismo Club");
        }
        else if (PB>TC&&PB>LF&&PB>SRF)
        {
            System.out.println("O time vencedor é Patinho Branquinho");
        }
        else if (LF>TC&&LF>SRF&&LF>PB)
        {
            System.out.println("O time vencedor é Lucas FC");
        }
        else if (SRF>TC&&SRF>PB&&SRF>LF)
        {
            System.out.println("O time vencedor é Sport Redes FC");
        }
        else
        {
            System.out.println("Não houve time vencedor, pois houve empate");
        }

    }
}
