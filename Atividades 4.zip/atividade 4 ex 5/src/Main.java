import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Random random = new Random();

        int numeroAleatorio = random.nextInt(100) + 1;

        int numero;

        System.out.println("O computador escolheu um número entre 1 e 100, tente advinhar qual é");
        do {
            System.out.print("Digite o seu numero: ");
            numero = scanner.nextInt();

            if (numero < numeroAleatorio) {
                System.out.println("O número é maior. Tente novamente.");
            } else if (numero > numeroAleatorio) {
                System.out.println("O número é menor. Tente novamente.");
            } else {
                System.out.println("Parabéns! Você acertou o número!");
            }
        } while (numero != numeroAleatorio);

        scanner.close();
    }
}