import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inicial para a contagem regressiva: ");
        int numeroInicial = scanner.nextInt();

        if (numeroInicial < 0) {
            System.out.println("Por favor, digite um número maior ou igual a 0.");
        } else {
            while (numeroInicial >= 0) {
                System.out.println(numeroInicial);
                numeroInicial--;
            }
        }

        scanner.close();
    }
}